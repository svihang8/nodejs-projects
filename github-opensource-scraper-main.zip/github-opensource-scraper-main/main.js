// 1. Request https://github.com/topics and open top 3 topics.
const request = require('request'); // Requires request
const cheerio = require('cheerio'); // Requires cheerio
const path = require('path'); // Requires path
const fs = require('fs'); // Requires fs

const url = 'https://github.com/topics'; // GitHub Topics URL

console.log('```````````````````````````````````````````````````````');
request(url, cb);

function cb (error, response, html) {
    if (error) {
        console.error(error);
    } else {
        getTopics(html);
    }
}

function getTopics (html) {
    const $ = cheerio.load(html);
    const topicBox = $('.topic-box');
    for(let i = 0 ; i < topicBox.length ; i++) {
        const topic = $(topicBox[i]).find('.f3').text().trim();
        console.log(topic);
        let link = $(topicBox[i]).find('a').attr('href');
        link = 'https://github.com/' + link;
        console.log(link);
        console.log('```````````````````````````````````````````````````````');
        requestTopics(link, topic);   
    }
}

function requestTopics(url, topic) {
    request(url, cb);
    function cb(error, response, html) {
        if(error) {
            console.error(error);
        } else {
            getRepos(html, topic);
        }
    }
}

function getRepos(html, topic) {
    const $ = cheerio.load(html);
    const listofRepos = $('h3 a[data-ga-click="Explore, go to repository, location:explore feed"]');
    for(let i = 0 ; i < 8 ; i++) {
        const repo = $(listofRepos[i]).text().trim();
        let link = $(listofRepos[i]).attr('href');
        link = 'https://github.com' + link + '/issues';
        console.log(`Repository Name: ${repo} , Repository Link: ${link}`);
        console.log('```````````````````````````````````````````````````````');
        requestReposIssues(link, repo, topic);
    }
}

function requestReposIssues(url, repo, topic) {
    request(url, cb);
    function cb(error, response, html) {
        if(error) {
            console.error(error);
        } else {
            getRepoIssues(html, repo, topic);
        }
    }
}

function getRepoIssues(html, repo, topic) {
    const $ = cheerio.load(html);
    const listofIssues = $('.js-navigation-container div a.Link--primary');
    let issues = [];
    for(let i = 0 ; i < listofIssues.length ; i++) {
        const issue = $(listofIssues[i]).attr('href');
        console.log(`Issue link : ${issue}`);
        console.log('```````````````````````````````````````````````````````');
        issues.push(issue);
    }
    console.log(issues);
    storeinJSONFile(topic, repo, issues);
}

function storeinJSONFile(topic, repo, issues) {
    const topicPath = path.join(__dirname, topic);
    let flag = fs.existsSync(topicPath);
    if(flag == false) {
        fs.mkdirSync(topicPath);
        console.log(`/${topic} directory created`);
        console.log('```````````````````````````````````````````````````````');
    }
    const repoPath = path.join(topicPath, repo);
    flag = fs.existsSync(repoPath + '.json');
    if(flag == false) {
        fs.writeFileSync(repoPath + '.json', '');
        console.log(`/${repo} file created`);
        console.log('```````````````````````````````````````````````````````');
    }
    let JsonString = JSON.stringify(issues);
    fs.appendFileSync(repoPath + '.json', JsonString);
}
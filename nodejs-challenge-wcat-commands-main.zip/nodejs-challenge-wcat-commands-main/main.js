let inputArr = process.argv.slice(2); // Input of commands and fileNames
const fs = require('fs');
const path = require('path');

let filesArr = []; // Stores the files inputed.

let optionsArr = []; // Stores the options inputed.

let processArr = []; // Stores the process ('>' and '>>' inputed) 


for(let i = 0 ; i < inputArr.length; i++) {
    let firstChar = inputArr[i].charAt(0);
    // console.log(firstChar);
    if(firstChar == "-") {
        optionsArr.push(inputArr[i]);
    } else {
        filesArr.push(inputArr[i]);
    }
}

// console.log(optionsArr);
// console.log(filesArr);

// Produce error if filesArr is empty
if (filesArr.length == 0) {
    console.error("No file given.");
    return;
}

// Produce error if optionsArr contains -n and -b
if (optionsArr.includes("-n") && optionsArr.includes("-b")) {
    console.error("-n and -b cannot be commanded together");
    return;
} 

// iterate through the files in filesArr
for (let i = 1; i < filesArr.length ; i++) {
    let fileName = filesArr[i - 1];
    let fileName2 = filesArr[i];
    // console.log(fileName);
    let filePath = path.join(__dirname, fileName);
    let file2Path = path.join(__dirname, fileName2);
    appendContent(filePath, file2Path);
}

// display content of a file
function displayFile(filePath) {
    let fileExists = fs.existsSync(filePath);
    if (fileExists) {
        console.log(fs.readFileSync(filePath, 'utf8'));
    } else {
        console.error("File doesn't exist");
        return;
    }
}

// implement -s
function sFile(filePath) {
    let fileExists = fs.existsSync(filePath);
    if (fileExists) {
        let fileData = fs.readFileSync(filePath, 'utf8');
        const lines = fileData.split(/\r?\n/);
        let appendedLines = [];
        for(let i = 0 ; i < lines.length ; i++) {
            if(appendedLines.length == 0 || lines[i] != "" || appendedLines[appendedLines.length - 1] != "") {
                appendedLines.push(lines[i]);
            }
        }
        fs.writeFileSync(filePath, "");
        for(let i = 0 ; i < appendedLines.length ; i++) {
            fs.appendFileSync(filePath, appendedLines[i] + "\n");
        }
        fileData = fs.readFileSync(filePath, 'utf8');
        console.log(fileData);
    } else {
        console.error("File doesn't exist");
        return;
    }
}

// implement -n option
function nFile(filePath) {
    let fileExists = fs.existsSync(filePath);
    if (fileExists) {
        let fileData = fs.readFileSync(filePath, 'utf8');
        let lines = fileData.split(/\r?\n/);
        let appendedLines = [];
        for(let i = 0; i < lines.length ; i++) {
            let appendedLine = (i + 1) + ". " + lines[i];
            appendedLines.push(appendedLine);
        }
        fs.writeFileSync(filePath, "");
        for(let i = 0 ; i < appendedLines.length ; i++) {
            fs.appendFileSync(filePath, appendedLines[i] + "\n");
        }
        fileData = fs.readFileSync(filePath, 'utf8');
        console.log(fileData);
    } else {
        console.error("File doesn't exist");
        return;
    }
}

// implement -b
function bFile(filePath) {
    let fileExists = fs.existsSync(filePath);
    if (fileExists) {
        let fileData = fs.readFileSync(filePath, 'utf8');
        let lines = fileData.split(/\r?\n/);
        let appendedLines = [];
        let num = 1;
        for(let i = 0 ; i < lines.length ; i++) {
            if(lines[i] != "") {
                appendedLines.push(`${num}. ${lines[i]}`);
                num++;
            } else {
                appendedLines.push(lines[i]);
            }
        }
        fs.writeFileSync(filePath, "");
        for(let i = 0 ; i < appendedLines.length ; i++) {
            fs.appendFileSync(filePath, appendedLines[i] + "\n");
        }
        fileData = fs.readFileSync(filePath, 'utf8');
        console.log(fileData);
    } else {
        console.error("File doesn't exist");
        return;
    }
}

// implement file1 > file2
function overrideContent(file1Path, file2Path) {
    let file1Exists = fs.existsSync(file1Path);
    if (file1Exists) {
        let file2Exists = fs.existsSync(file2Path);
        console.log(fs.readFileSync(file1Path, 'utf8'));
        let file1Data = fs.readFileSync(file1Path, 'utf8');
        let file1lines = file1Data.split('\n');
        if(file2Exists == false) {
            fs.writeFileSync(file2Path, "");
        }
        console.log(fs.readFileSync(file2Path, 'utf8'));        
        fs.writeFileSync(file2Path, "");
        console.log(fs.readFileSync(file2Path, 'utf8'));
        for(let i = 0; i < file1lines.length; i++) {
            fs.appendFileSync(file2Path, file1lines[i] + "\n");
        }
        console.log(fs.readFileSync(file2Path, 'utf8'));
    } else {
        console.error("File doesn't exist");
    }
}


// implement file1 >> file2
function appendContent(file1Path, file2Path) {
    let file1Exists = fs.existsSync(file1Path);
    if (file1Exists) {
        let file2Exists = fs.existsSync(file2Path);
        console.log(fs.readFileSync(file1Path, 'utf8'));
        let file1Data = fs.readFileSync(file1Path, 'utf8');
        let file1lines = file1Data.split('\n');
        if(file2Exists == false) {
            fs.writeFileSync(file2Path, "");
        }        
        console.log(fs.readFileSync(file2Path, 'utf8'));
        for(let i = 0; i < file1lines.length; i++) {
            fs.appendFileSync(file2Path, "\n" + file1lines[i]);
        }
        console.log(fs.readFileSync(file2Path, 'utf8'));
    } else {
        console.error("File doesn't exist");
    }
}




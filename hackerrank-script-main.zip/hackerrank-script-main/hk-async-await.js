const puppeteer = require('puppeteer'); // import puppeteer
const fs = require('fs');
const loginLink = 'https://www.hackerrank.com/auth/login'; // hackerrank login url

const username = 'email@provider.com'; // hackerrank username
const password = '**************'; // hackerrank password
const question = 'Two Array Sum'; // Question
const code =
`
Sample Code
` // Code

(async function(){
    try {
        let browserInstance = await puppeteer.launch({
            headless: false,
        
            args: ['--start-maximized'],
        
            defaultViewport: null
        })
        let newTab = await browserInstance.newPage();
        let page = newTab;
        await page.goto(loginLink);

        await page.waitForSelector("input[type='text']");
        await page.type("input[type='text']", username);
        await page.type("input[type='password']", password);
        await page.keyboard.press('Enter');
        await page.waitForSelector('.ac-input');
        await page.type('.ac-input', question);
        await page.keyboard.press('Enter');
        await page.waitForSelector('li .highligted')
        await page.click('li .highligted');      
        await page.waitForSelector('.checkbox-input')
        await page.click('.checkbox-input')
        await page.waitForSelector('.custominput')
        await page.type('.custominput', code);
        await page.evaluate( () => document.execCommand( 'selectall', false, null ) );
        await page.evaluate( () => document.execCommand('cut'))
        await page.click('.monaco-editor.no-user-select.vs')
        await page.type('.monaco-editor.no-user-select.vs', 'typing')
        await page.evaluate( () => document.execCommand( 'selectall', false, null ) );
        //await browserInstance.close();
    } catch (error) {
        console.log(error);
    }
})()
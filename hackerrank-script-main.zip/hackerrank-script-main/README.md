# HackerRank Automation Submission Script
HackerRank Automation Script 

## Installation
Install Node.js from https://nodejs.org/en/

Clone this git repository.

```Terminal
git clone <template-directory>
```

Initialize a npm package
```Terminal
npm init -y
npm install puppeteer
```

## Usage
To automate the script, enter your email, password, question name, and your input code.
Then run the script
```Terminal
node <file_name>
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change. It will be much appreciated if someone could add more functionalities. Currently i am working on taking input from some online text editor so everything is easier for the user.

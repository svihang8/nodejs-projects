let fs  = require('fs');
let path = require('path');
let types = {
    media: ["mp4", "mkv", "mov"],
    archives: ['zip', '7z', 'rar', 'tar', 'gz', 'ar', 'iso', 'xz'],
    documents: ['docx', 'doc', 'pdf', 'xlsx', 'xls', 'odt', 'ods', 'odp','txt'],
    app: ['exe','dmg', 'pkg', 'deb']
}

function organizeFn(dirPath) {
    let destPath;
    // console.log("Organize implemented for", dirPath);
    // 1. input -> directory path given
    if (dirPath == undefined) { // dirPath not given
        dirPath = process.cwd();
        organizeFn(dirPath);
    } else {
        let doesExist = fs.existsSync(dirPath);
        if(doesExist) {
            // 2. create -> organized_files -> directory
            destPath = path.join(dirPath, "organized_files");
            if(fs.existsSync(destPath) == false) {
                fs.mkdirSync(destPath);
            }

        } else {
            console.log("Kindly enter the correct directory path");
            return;
        }
    }
    organizeHelper(dirPath, destPath);


}

function organizeHelper(src, dest) {
    // 3. identify categories of all files present in that input directory
    let childNames = fs.readdirSync(src);
    for(let i = 0 ; i < childNames.length; i++) {
        console.log(childNames[i]);
        let childAdress = path.join(src, childNames[i]);
        console.log(childAdress);
        let isFile = fs.lstatSync(childAdress).isFile();
        let isDirectory = fs.lstatSync(childAdress).isDirectory();
        if (isFile) {
            let category = getCategory(childNames[i]);
            // 4. copy / cut files to that organized directory inside of any category folder
            sendFiles(childAdress, dest, category);

        }
        if (isDirectory && childNames[i] != "organized_files") {
            organizeHelper(childAdress, dest);
        } 
    }
}

function getCategory(name) {
    let ext = path.extname(name);
    ext = ext.slice(1);
    for(let type in types) {
        let CTypeArray = types[type];
        for(let i = 0; i < CTypeArray.length; i++) {
            if (ext == CTypeArray[i]) {
                return type;
            }
        }
    }
    return "others";
}

function sendFiles(srcFilePath, dest, category) {
    let categoryPath = path.join(dest, category);
    if(fs.existsSync(categoryPath) == false) {
        fs.mkdirSync(categoryPath);
    }
    let fileName = path.basename(srcFilePath);
    let destFilePath = path.join(categoryPath, fileName);
    fs.copyFileSync(srcFilePath, destFilePath);
    // fs.unlinkSync(srcFilePath); // comment out if files should not be deleted from source path.
}



module.exports = {
    organizeKey: organizeFn
}
# ESPN IPL Cricket Scraper
ESPN IPL Cricket Scraper is a web scraping project that can extract data for each player from either a scorecard, or a whole season.

## Installation
Install Node.js from https://nodejs.org/en/

Clone this git repository.

```Terminal
git clone <template-directory>
```

Initialize a npm package
```Terminal
npm init -y
npm install cheerio
```

## Usage
To scrape the data from a scorecard,
Ex. https://www.espncricinfo.com/series/ipl-2021-1249214/chennai-super-kings-vs-kolkata-knight-riders-final-1254117/full-scorecard

```Terminal
node scorecards.js <url>
```
To scrape the data from a whole season,
Ex. https://www.espncricinfo.com/series/ipl-2021-1249214

```
node season.js <url>
```

If not existing, an IPL directory will be created with each player's data in a subdirectory of the team they played in for that particular season. Example: ./IPL/Sunrisers-Hyderabad/David-Warner.txt

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change. It will be much appreciated if someone could use this data for purposes of data visualization, and analysis. Also, support would be accepted to convert data to JSON files, PDF files, and other ways to represent data.

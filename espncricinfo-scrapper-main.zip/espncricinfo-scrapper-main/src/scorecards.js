const request = require('request'); // Requires request
const cheerio = require('cheerio'); // Requires cheerio
const path = require('path'); // Requires path
const fs = require('fs'); // Requires fs

let url = "https://www.espncricinfo.com/series/ipl-2021-1249214/chennai-super-kings-vs-kolkata-knight-riders-final-1254117/full-scorecard";

function openScoreCard(url) {
    request(url, cb);

    function cb(error, response, html) {
        if (error) {
            console.error(error); // Give error if error
        } else {
            evaluateScoreCard(html);
        }
    }
}

function evaluateScoreCard(html) {
    const $ = cheerio.load(html);
    let matchInfo = $('div .match-header-container');
    let matchInfoHtml = matchInfo.html();
    let matchInfoList = getMatchInformation(matchInfoHtml);
    console.log(matchInfoList);
    if (matchInfoList[4] == 'No result') {
        return;
    }
    const listofTeamBatting = $('.Collapsible__contentInner');
    const Team1BattingTable = $(listofTeamBatting[0]).html();
    const Team2BattingTable = $(listofTeamBatting[1]).html();
    fillTeamInformation(Team1BattingTable, matchInfoList, matchInfoList[2]);
    fillTeamInformation(Team2BattingTable, matchInfoList, matchInfoList[3]);

}

function getMatchInformation(html) {
    const $ = cheerio.load(html);
    const matchInfo = $('div .description');
    let matchInfoText = matchInfo.text();
    let matchInfoList = matchInfoText.split(', ');
    const venue = matchInfoList[1];
    const date = matchInfoList[2];
    const teams = $('p.name');
    const team1 =  $(teams[0]).text();
    const team2 = $(teams[1]).text();
    const status = $('div.status-text').text();
    return [venue, date, team1, team2, status];
}

function fillTeamInformation(html, details, teamName) {
    const $ = cheerio.load(html);
    const teamPath = makeTeamFile(__dirname, teamName);
    const tableRows = $('tbody tr');
    let listofBatsmen = [];
    for(let i = 0 ; i < tableRows.length ; i++) {
        let tableData = $(tableRows[i]).find("td");
        if($(tableData[0]).hasClass("batsman-cell")) {
            let namefromtable = $(tableData[0]).find('a').text();
            let nameList = namefromtable.split('');
            let name = '';
            for(let j = 0 ; j < nameList.length ; j++) {
                if(nameList[j] == '†' || nameList[j] == '(') {
                    break;
                }
                name = name + nameList[j];
            }
            name = name.trim();
            // console.log(name);
            let reasonOfWicket = $(tableData[1]).find('span').text().trim();
            if(reasonOfWicket == "") {
                reasonOfWicket = 'not out';
            }
            // console.log(reasonOfWicket);
            const runs = $(tableData[2]).text();
            // console.log(runs);
            const balls = $(tableData[3]).text();
            // console.log(balls);
            const fours = $(tableData[5]).text();
            // console.log(fours);
            const sixes = $(tableData[6]).text();
            // console.log(sixes);
            const strikerate = $(tableData[7]).text();
            let information = [name, reasonOfWicket, runs, balls, fours, sixes, strikerate];
            addInformation(information, details, teamPath);
        }
    }

}

function addInformation(information, details, teamPath) {
    let playerPath = path.join(teamPath, information[0]);
    let printVal = '\n' + `At ${details[0]}, on ${details[1]}, ${details[4]}
    Runs: ${information[2]} ; Balls: ${information[3]} ; ${information[1]} ; SR ${information[6]}`;
    console.log(printVal);
    let flag = fs.existsSync(playerPath + '.txt');
    if(flag == false) {
        fs.appendFileSync(playerPath + '.txt', `Name: ${information[0]}`);
    }
    fs.appendFileSync(playerPath + '.txt', printVal);

}

function makeTeamFile(dirPath, team) {
    let teamPath = path.join(dirPath, 'IPL' ,team);
    let flag = fs.existsSync(teamPath);
    if(flag == false) {
        fs.mkdirSync(teamPath);
    }
    return teamPath;
}


exports.evaluateScoreCard = openScoreCard;
const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
})
const evalScorecard = require('./scorecards.js');
const evalSeason = require('./season.js');
const values = ['scorecard', 'season']

function takeInput(idx) {
    readline.question(`${values[idx]}(Y/N)`, input => {
        if (input == 'y' || input == 'Y') {
            getUrl(values[idx]);
        } else if (input == 'n' || input == 'N') {
            takeInput((idx + 1) % values.length);
        } else {
            console.error('Wrong input');
            takeInput(idx);
        }
    })
}

function getUrl(value) {
    readline.question('Url:- ', url => {
        if (value == 'scorecard') {
            evalScorecard(url)
        } else {
            evalSeason(url);
        }
    })
}

takeInput(1);
const request = require('request'); // Requires request
const cheerio = require('cheerio'); // Requires cheerio
const path = require('path'); // Requires path
const fs = require('fs'); // Requires fs
const evalScoreCard = require('./scorecards.js'); // Requires

const urlLists = ['https://www.espncricinfo.com/series/ipl-2021-1249214',
    'https://www.espncricinfo.com/series/ipl-2020-21-1210595',
    'https://www.espncricinfo.com/series/ipl-2019-1165643',
    'https://www.espncricinfo.com/series/ipl-2018-1131611',
    'https://www.espncricinfo.com/series/ipl-2017-1078425',
    'https://www.espncricinfo.com/series/ipl-2016-968923',
    'https://www.espncricinfo.com/series/pepsi-indian-premier-league-2015-791129',
    'https://www.espncricinfo.com/series/pepsi-indian-premier-league-2014-695871',
    'https://www.espncricinfo.com/series/indian-premier-league-2013-586733',
    'https://www.espncricinfo.com/series/indian-premier-league-2012-520932',
    'https://www.espncricinfo.com/series/indian-premier-league-2011-466304',
    'https://www.espncricinfo.com/series/indian-premier-league-2009-10-418064',
    'https://www.espncricinfo.com/series/indian-premier-league-2009-374163',
    'https://www.espncricinfo.com/series/indian-premier-league-2007-08-313494'
]

function initiateProcess(url) {
    let iplpath = path.join(__dirname, 'IPL');
    let iplexists = fs.existsSync(iplpath);
    if (iplexists === false) {
        fs.mkdirSync('IPL');
    }

    request(url, function cb(error, response, html) {
        if (error) {
            console.error(error); // Give error if error
        } else {
            openScoreCardsLink(html);
        }
    });

}


function openScoreCardsLink(html) {
    const $ = cheerio.load(html);
    let allScoreCardsA = $("a[data-hover='View All Results']");
    let link = allScoreCardsA.attr('href');
    link = "https://www.espncricinfo.com/" + link;
    openScoreCards(link);

}


function openScoreCards(url) {
    console.log(url);
    request(url, cb);

    function cb(error, response, html) {
        if (error) {
            console.error(error); // Give error if error
        } else {
            openEachScoreCard(html);
        }
    }
}


function openEachScoreCard(html) {
    const $ = cheerio.load(html);
    let listofScoreCards = $('a[data-hover="Scorecard"]');

    for (let i = listofScoreCards.length - 1; i >= 0; i--) {
        let scorecard = $(listofScoreCards[i]);
        let linkOfScoreCard = scorecard.attr('href');
        linkOfScoreCard = "https://www.espncricinfo.com/" + linkOfScoreCard;
        console.log(linkOfScoreCard);
        evalScoreCard.evaluateScoreCard(linkOfScoreCard);
    }
}


module.exports = initiateProcess;